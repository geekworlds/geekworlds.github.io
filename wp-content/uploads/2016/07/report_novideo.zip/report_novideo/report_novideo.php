<?php
/*
Plugin Name: Report No Video
Version: 1.0
Author: Ritesh Bathwal 
Description: This plugin will generate a button on the posts to report for no videos and will notify admin about the same.
*/


add_action( 'init', 'report_script_enqueuer' );
function report_script_enqueuer() {
	 wp_register_script( "reportJS", WP_PLUGIN_URL.'/report_novideo/js/report.js', array('jquery'), 1.0 );
	 wp_enqueue_script( 'jquery' );
	 wp_enqueue_script('reportJS');
	 wp_localize_script( 'reportJS', 'reportAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) )); 	 
	 
 	 wp_register_style('reportCSS', WP_PLUGIN_URL.'/report_novideo/css/report.css');
	 wp_enqueue_style('reportCSS');	  
}


add_shortcode('report_novideo','report_novideo_shortcode_handler');
function report_novideo_shortcode_handler(){	
	global $wpdb;
	
	echo "<div class='clear'></div><div id='post_report_sec'>
			<div style='float:left;'>
				<input id='report_novideo' style='cursor:pointer;' type='button' value='Report Deleted Video' title='Reports to admin about video not available'>
			</div>	
			<div style='float:left;'><span style='margin-left:5px !important;' class='spinner'> </span></div>
	</div><div class='clear'></div>";	
}


add_filter( 'the_content', 'add_report_novideo_shortcode_to_all_posts' );
function add_report_novideo_shortcode_to_all_posts( $content ) {
  global $post;
  if( ! $post instanceof WP_Post ) return $content;

  switch( $post->post_type ) {
    case 'post':
      return $content . ' [report_novideo]';

    default:
      return $content;
  }
}



add_action("wp_ajax_del_reported_post", "del_reported_post");
add_action("wp_ajax_nopriv_del_reported_post", "del_reported_post");
function del_reported_post(){
	$reported_ids = get_option('reported_video_post_ids');
	
	if($reported_ids==NULL){
		die(0);
	}
	
	if(!in_array($_POST['post_id'], $reported_ids)){
		$new_reported_ids = array();
		foreach($reported_ids as $id){
			if($id == $_POST['post_id']) continue;
			
			$new_reported_ids[] = $id;
		}
	}
	 
	update_option('reported_video_post_ids', $new_reported_ids);
	
	echo "Success";	
}


add_action("wp_ajax_report_novideo", "report_novideo");
add_action("wp_ajax_nopriv_report_novideo", "report_novideo");
function report_novideo(){
	$reported_ids = get_option('reported_video_post_ids');
	
	if($reported_ids==NULL){
		$reported_ids = array();
	}
	
	
	if(!in_array($_POST['post_id'], $reported_ids))
		$reported_ids[] = $_POST['post_id'];
	 
	update_option('reported_video_post_ids', $reported_ids);
	
	echo "Success";
	die(0);
}


add_action( 'admin_menu', 'report_no_video_list_menu' );		
function report_no_video_list_menu(){
	//add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position ); 		
	add_menu_page('Reported Posts', 'Reported Posts', 'manage_options', 'reported_posts', 'reported_posts_page');
}

function reported_posts_page(){		
	include('admin/reported_posts_page.php');
}
