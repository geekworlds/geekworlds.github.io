jQuery(document).ready(function($){
	console.log("Report NO Video js enqueued");
	
	$("#report_novideo").click(function(){
		$("#post_report_sec .spinner").addClass("is-active");
		console.log("Report Video Butotn clicked");
		var post_id = $('.dp-like-post .like').data("pid");
		
		if(typeof post_id == 'undefined' || post_id==''){
			post_id = $('.dp-like-post .liked').data("pid");
		}
		
		console.log("POST ID:" + post_id);
		
		$.ajax({	
			url: reportAjax.ajaxurl, 
			data: {action:'report_novideo', post_id:post_id},
			type: "POST",			
			success: function(res){
				console.log("Video Reported Success Message:" +  res);
				$("#post_report_sec .spinner").removeClass("is-active");
			}
        });			
	});
	
	
	$("#reported_posts_table .reported_post_del").click(function(){
		console.log("Del Button Clicked");
		var post_id = $(this).data("post_id");		
		var ans 	= confirm("Are you sure to remove it from the list");
		var self	= $(this);
		if(ans){		
			$.ajax({	
				url: reportAjax.ajaxurl, 
				data: {action:'del_reported_post', post_id:post_id},
				type: "POST",			
				success: function(res){
					console.log("Reported POST is removed from the list now:" +  res);
					self.closest("tr").fadeOut("slow").remove();
				}
			});			
			
		} //if
	
	});

});