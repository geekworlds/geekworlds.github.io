<style>
	#reported_posts_table td, #reported_posts_table th{		
		text-align:center;
		border: 1px solid black;
		padding: 5px;
	}
	
	#reported_posts_table th{
		background:grey;
		color:white;
		font-weight:bold;
		
	}
	
	#reported_posts_table{
		width:95%;
		box-sizing:border:box;
		padding:15px;
		background:white;
		border-collapse:collapse;
	}
	
	.reported_post_del{
		cursor:pointer;
	}
	
	.reported_title{
		text-transform:uppercase;
		text-align:center;
		color: #dd3333;
		letter-spacing: 1px;
	}
</style>

<?php
	
	
	
	echo "<h1 class='reported_title'>Reported Posts</h1>";
	$reported_posts =  get_option(	'reported_video_post_ids' );
	
	echo "<table id='reported_posts_table'>";
	echo "<th style='width:10%'>S.N.</th><th style='width:40%'>Title</th><th style='width:40%'>View Post</th><th style='width:10%'>Remove</th>";
	$i=1;
	foreach($reported_posts as $reported){
		
		echo "
			<tr>
				<td>".$i."</td>
				<td style='text-transform:uppercase;'>". get_the_title($reported) ."</td>
				<td><a href='".get_permalink($reported)."' target='_blank' > View </a></td>
				<td><span data-post_id='".$reported."' class='dashicons dashicons-trash reported_post_del'></span></td>
			</tr>";
			
			$i++;
	}
	
	echo "</table>";

?>